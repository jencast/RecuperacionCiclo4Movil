package co.com.cesardiaz.misiontic.mytask;

public enum TaskState {
    PENDING,
    DONE
}
